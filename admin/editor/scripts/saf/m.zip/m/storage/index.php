<?php
//phpinfo();
//URL- http://174.121.226.32/~themaile/m/