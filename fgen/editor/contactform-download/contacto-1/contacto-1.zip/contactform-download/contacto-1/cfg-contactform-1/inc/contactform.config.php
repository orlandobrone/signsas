<?php
$cfg['email_address'] = 'callcenter@singsas.com';
$cfg['email_from'] = '';
$cfg['email_address_cc'] = 'gerencia@pymagen.com';
$cfg['email_address_bcc'] = '';
$cfg['timezone'] = 'America/Chicago';
$cfg['form_name'] = 'contacto';
$cfg['form_validationmessage'] = 'Gracias';
$cfg['form_errormessage_captcha'] = '';
$cfg['form_errormessage_emptyfield'] = 'debe llenarlo';
$cfg['form_errormessage_invalidemailaddress'] = 'Correo incorrecto';
$cfg['form_redirecturl'] = '';
$cfg['adminnotification_subject'] = 'Nuevo mensaje desde pagina web';
$cfg['usernotification_inputid'] = '';
$cfg['usernotification_insertformdata'] = '';
$cfg['usernotification_format'] = '';
$cfg['usernotification_subject'] = '';
$cfg['usernotification_message'] = '';
?>
