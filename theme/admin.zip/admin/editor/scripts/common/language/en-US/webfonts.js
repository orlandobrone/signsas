function loadTxt() {
    document.getElementById("tab0").innerHTML = "GOOGLE FONTS";
    document.getElementById("tab1").innerHTML = "BASIC FONTS";
    }
function writeTitle() {
    document.write("<title>" + "Fonts" + "</title>")
    }