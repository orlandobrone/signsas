﻿function loadTxt() {

}
function writeTitle() {
    document.write("<title>" + "Specialtecken" + "</title>")
}