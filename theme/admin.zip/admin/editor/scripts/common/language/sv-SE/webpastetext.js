function loadTxt()
	{
    document.getElementById("txtLang").innerHTML = "Klistra in text här (CTRL-V) ";
    document.getElementById("btnCancel").value = "Stäng";
    document.getElementById("btnOk").value = " OK ";   
	}
function writeTitle()
	{
	document.write("<title>Klistra in text</title>")
	}

