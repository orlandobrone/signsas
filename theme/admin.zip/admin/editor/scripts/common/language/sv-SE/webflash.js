﻿function loadTxt() {
    document.getElementById("lblSource").innerHTML = "KÄLLA:";
    document.getElementById("lblWidth").innerHTML = "BREDD:";
    document.getElementById("lblHeight").innerHTML = "HÖJD:";
    document.getElementById("btnCancel").innerHTML = "Stäng";
    document.getElementById("btnInsert").value = " Infoga ";
}

function writeTitle() {
    document.write("<title>Flash</title>")
}