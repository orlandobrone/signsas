﻿function loadTxt() {

}
function writeTitle() {
    document.write("<title>" + "Edit&eacute;ur HTML" + "</title>")
}