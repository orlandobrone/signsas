﻿function loadTxt() {

}
function writeTitle() {
    document.write("<title>" + "Caractères Spéciaux" + "</title>")
}