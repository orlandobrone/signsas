﻿function loadTxt() {

}
function writeTitle() {
    document.write("<title>" + "Caract&egrave;res sp&eacute;ciaux" + "</title>")
}