﻿function loadTxt() {

}
function writeTitle() {
    document.write("<title>" + "HTML editor" + "</title>")
}