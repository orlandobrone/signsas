function loadTxt()
	{
    document.getElementById("txtLang").innerHTML = "Inds�t tekst her (CTRL-V) ";
    document.getElementById("btnCancel").value = "annuller";
    document.getElementById("btnOk").value = " ok ";   
	}
function writeTitle()
	{
	document.write("<title>Inds�t tekst</title>")
	}

