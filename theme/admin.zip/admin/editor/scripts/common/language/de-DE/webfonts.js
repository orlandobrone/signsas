function loadTxt() {
    document.getElementById("tab0").innerHTML = "GOOGLE SCHRIFTARTEN";
    document.getElementById("tab1").innerHTML = "STANDARD SCHRIFTARTEN";
    }
function writeTitle() {
    document.write("<title>" + "SCHRIFTARTEN" + "</title>")
    }