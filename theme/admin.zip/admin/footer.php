<?php
  /**
   * Footer
   *
   * @package CMS Pro
   * @author wojoscripts.com
   * @copyright 2010
   * @version $Id: footer.php, v2.00 2011-04-20 10:12:05 gewa Exp $
   */
  
  if (!defined("_VALID_PHP"))
      die('Direct access to this location is not allowed.');
?>
<!-- Start Footer-->
<div id="footer" class="clearfix">
  <div id="footer-inner">Copyright &copy;<?php echo date('Y').' '.$core->site_name;?> &bull; Powered by: CMS Pro m2 v <?php echo $core->version;?></div>
</div>
</div>
<!-- End Footer-->
</body></html>