<?php
  /**
   * Posts
   *
   * @package CMS Pro
   * @author wojoscripts.com
   * @copyright 2010
   * @version $Id: posts.php, v2.00 2011-04-20 10:12:05 gewa Exp $
   */
  if (!defined("_VALID_PHP"))
      die('Direct access to this location is not allowed.');
?>

<div id="dialog" title="<?php echo _HP_POSTS_TITLE;?>">
  <?php echo _HP_POSTS_BODY;?>
  <ul class="box">
    <li class="info"><?php echo _HP_POSTS_TIP;?></li>
  </ul>
</div>