<?php
  /**
   * Layout
   *
   * @package CMS Pro
   * @author wojoscripts.com
   * @copyright 2010
   * @version $Id: layout.php, v2.00 2011-04-20 10:12:05 gewa Exp $
   */
  if (!defined("_VALID_PHP"))
      die('Direct access to this location is not allowed.');
?>

<div id="dialog" title="<?php echo _HP_LAYOUT_TITLE;?>">
  <div class="box"><?php echo _HP_LAYOUT_BODY;?></div>
</div>